class CategoryModel {
  final String type;
  final int categoryKey;

  CategoryModel({this.type, this.categoryKey});
}
