import firebase from 'firebase';

export default firebase.initializeApp({
    apiKey: "AIzaSyBnJSfpeU2m1LXDVpoSGw4ZzJtZaZJWP3E",
    authDomain: "loginpro-7c306.firebaseapp.com",
    databaseURL: "https://loginpro-7c306.firebaseio.com",
    projectId: "loginpro-7c306",
    storageBucket: "loginpro-7c306.appspot.com",
    messagingSenderId: "1064500431871",
    appId: "1:1064500431871:web:56789d87ca7bed473275ca"
});

export const auth = firebase.auth();
export const firestore = firebase.firestore();
