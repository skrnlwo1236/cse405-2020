import React from 'react';
import { AuthConsumer } from './auth-context';

const guestComponent = (Component, otherComponent = null) => (
  <AuthConsumer>
    {({ guest }) => (guest() ? Component : otherComponent)}
  </AuthConsumer>
);

export default guestComponent;
