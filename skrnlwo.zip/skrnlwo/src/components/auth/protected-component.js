import React from 'react';
import { AuthConsumer } from './auth-context';

const protectedComponent = (Component, otherComponent = null) => (
  <AuthConsumer>
    {({ check }) => (check() ? Component : otherComponent)}
  </AuthConsumer>
);

export default protectedComponent;
