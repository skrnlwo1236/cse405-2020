import React, { Component } from 'react';
import { Link, NavLink } from 'react-router-dom';
import protectedComponent from './auth/protected-component';
import { auth } from '../util/firebase';

const NavbarBurger = ({ active, onClick }) => (
  <div
    className={`navbar-burger burger ${active ? 'is-active' : ''}`}
    onClick={onClick}
  >
    <span />
    <span />
    <span />
  </div>
);

const NavbarLink = ({ children, ...rest }) => (
  <NavLink className="navbar-item" activeClassName="is-active" {...rest}>
    {children}
  </NavLink>
);

class Navbar extends Component {
  state = {
    isMenuExpanded: false
  };

  render() {
    const { isMenuExpanded } = this.state;

    return (
      <nav className="navbar is-dark">
        <div className="container">
          <div className="navbar-brand">
            <Link to="/" className="navbar-item">
              <h1>
               My App
              </h1>
            </Link>
            <NavbarBurger
              active={isMenuExpanded}
              onClick={() => this.setState({ isMenuExpanded: !isMenuExpanded })}
            />
          </div>

          <div className={`navbar-menu ${isMenuExpanded ? 'is-active' : ''}`}>
            <div className="navbar-start">
              {protectedComponent(
                <NavbarLink to="/home" exact>
                  Home
                </NavbarLink>
              )}
            </div>
            <div className="navbar-end">
              {protectedComponent(
                <a className="navbar-item" onClick={() => auth.signOut()}>
                  Logout
                </a>,
                <NavbarLink to="/">Login</NavbarLink>
              )}
            </div>
          </div>
        </div>
      </nav>
    );
  }
}

export default Navbar;
