export { default as Login } from './login';
export { default as Home } from './home';
export { default as Register } from './register';
