import React, { Component} from 'react';
import { Link } from 'react-router-dom';
import Input from '../input';
import { auth,firestore } from '../../util/firebase';


class Register extends Component {
  state = {
    name: '',
    email: '',
    password: '',
    formError: null,
    isLoading: false
  };

  handleChange({ target }) {
    const { name, value } = target;
    this.setState({
      [name]: value,
    });
  }

  handleSubmit(e) {
    e.preventDefault();
    const { name, email, password } = this.state;
    
    auth.createUserWithEmailAndPassword(email, password).then(data=>{
      this.saveDataToFireStore(data)
    }).catch(err =>{
      alert(err.message)
      this.setState({
        isLoading : false
      })
    }
    
    );
  }

  saveDataToFireStore(data){

   firestore.collection('users/').doc(data.user.uid).set({
     name : this.state.name,
     email : this.state.email,
   })

  }

 

  render() {
    return (
      <section className="section">
        <div className="container">
         
            <h1 className="title is-4">Register</h1>
            <form onSubmit={e => this.handleSubmit(e)}>
              
              <Input label="Name">
                <input
                  name="name"
                  type="name"
                  placeholder="Name"
                  value={this.state.name}
                  disabled={this.state.isLoading}
                  onChange={e => this.handleChange(e)}
                />
              </Input>

              <Input label="Email">
                <input
                  name="email"
                  type="email"
                  placeholder="Email Address"
                  ref={this.emailInput}
                  value={this.state.email}
                  disabled={this.state.isLoading}
                  onChange={e => this.handleChange(e)}
                />
              </Input>
              <Input label="Password">
                <input
                  name="password"
                  type="password"
                  placeholder="Password"
                  value={this.state.password}
                  disabled={this.state.isLoading}
                  onChange={e => this.handleChange(e)}
                />
              </Input>
              <div className="field">
                <div className="control">
                  <button
                    className={`button is-link`}
                    disabled={this.state.isLoading}
                  >
                    Register
                  </button>
                </div>
              </div>
            </form>
            <div className="content" style={{ marginTop: 5 }}>
              <p>
                OR  <Link to="/">Login</Link>.
              </p>
            </div>
          </div>
      </section>
    );
  }
}

export default Register;
