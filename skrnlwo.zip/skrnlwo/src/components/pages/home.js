import React, { Component } from 'react';
import { auth, firestore } from '../../util/firebase';


class Home extends Component {
  constructor() {
    super();
    this.state = {
      email: '',
      name: ''
    };
  }

  getDataFromFirestore() {
    console.log(auth.currentUser.uid);
    firestore
      .collection('users')
      .doc(auth.currentUser.uid)
      .get()
      .then(userdata => {
        userdata = userdata.data();
        console.log(userdata);
        this.setState(userdata)
      });
  }
  componentDidMount(){
    this.getDataFromFirestore();
  }

  render() {
    return (
      <section className="section">
        <div className="container">
           
          <div className="content">
           <h1>Name : {this.state.name}</h1>
           <h1>Email : {this.state.email}</h1>
            
          </div>
        </div>
      </section>
    );
  }
}

export default Home;
