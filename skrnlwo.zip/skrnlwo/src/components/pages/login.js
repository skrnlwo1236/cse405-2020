import React, { Component} from "react";
import { Link } from "react-router-dom";
import Input from "../input";
import { auth } from "../../util/firebase";

class Login extends Component {
  state = {
    email: "",
    password: "",
    formError: null,
    isLoading: false,
  };


  change({ target }) {
    const { name, value } = target;
    this.setState({
      [name]: value,
    });
  }

  handleSubmit(e) {
    e.preventDefault();
    const { email, password } = this.state;
  
    this.setState({ isLoading: true }, () =>
      auth.signInWithEmailAndPassword(email, password).catch((err) => {
        alert(err.message);
        this.setState({
          isLoading: false,
        });
      })
    );
  }

  render() {
    return (
      <section className="section">
        <div className="container">
          <h1 className="title is-4">Login</h1>
          <form onSubmit={(e) => this.handleSubmit(e)}>
            <Input label="Email">
              <input
                name="email"
                type="email"
                placeholder="Email Address"
                ref={this.emailInput}
                value={this.state.email}
                disabled={this.state.isLoading}
                onChange={(e) => this.change(e)}
              />
            </Input>
            <Input label="Password">
              <input
                name="password"
                type="password"
                placeholder="Password"
                value={this.state.password}
                disabled={this.state.isLoading}
                onChange={(e) => this.change(e)}
              />
            </Input>
            <div className="field">
              <div className="control">
                <button
                  className={`button is-link`}
                  disabled={this.state.isLoading}
                >
                  Login
                </button>
              </div>
            </div>
          </form>
          <div className="content" style={{ marginTop: 5 }}>
            <p>
              Or <Link to="/register">Register</Link>.
            </p>
          </div>
        </div>
      </section>
    );
  }
}

export default Login;
